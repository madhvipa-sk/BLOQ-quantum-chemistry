import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
import matplotlib.pyplot as plt
import seaborn as sns

class FinancialHealthAnalyzer:
    """
    Comprehensive financial health analyzer for pharmaceutical companies
    Specifically designed for DR Reddys Laboratories financial assessment
    """
    
    def __init__(self, financial_data: pd.DataFrame):
        """Initialize analyzer with financial data"""
        self.data = financial_data
        self.ratios = {}
        self.trends = {}
        self.health_score = 0
        
    # PROFITABILITY RATIOS
    def calculate_profit_margins(self) -> Dict[str, float]:
        """Calculate various profit margins"""
        margins = {
            'gross_profit_margin': (self.data['gross_profit'] / self.data['revenue']) * 100,
            'operating_profit_margin': (self.data['operating_profit'] / self.data['revenue']) * 100,
            'net_profit_margin': (self.data['net_profit'] / self.data['revenue']) * 100,
            'ebitda_margin': (self.data['ebitda'] / self.data['revenue']) * 100,
        }
        return margins
    
    def calculate_return_ratios(self) -> Dict[str, float]:
        """Calculate ROE and ROA"""
        returns = {
            'roe': (self.data['net_profit'] / self.data['equity']) * 100,
            'roa': (self.data['net_profit'] / self.data['total_assets']) * 100,
            'roic': (self.data['ebit'] * (1 - self.data['tax_rate'])) / 
                    (self.data['equity'] + self.data['debt']) * 100,
        }
        return returns
    
    # LIQUIDITY RATIOS
    def calculate_liquidity_ratios(self) -> Dict[str, float]:
        """Calculate liquidity and working capital ratios"""
        liquidity = {
            'current_ratio': self.data['current_assets'] / self.data['current_liabilities'],
            'quick_ratio': (self.data['current_assets'] - self.data['inventory']) / 
                          self.data['current_liabilities'],
            'cash_ratio': self.data['cash'] / self.data['current_liabilities'],
            'working_capital': self.data['current_assets'] - self.data['current_liabilities'],
            'working_capital_ratio': ((self.data['current_assets'] - self.data['current_liabilities']) / 
                                     self.data['total_assets']) * 100,
        }
        return liquidity
    
    # SOLVENCY RATIOS
    def calculate_solvency_ratios(self) -> Dict[str, float]:
        """Calculate leverage and debt ratios"""
        solvency = {
            'debt_to_equity': self.data['total_debt'] / self.data['equity'],
            'debt_to_assets': self.data['total_debt'] / self.data['total_assets'],
            'equity_ratio': self.data['equity'] / self.data['total_assets'],
            'interest_coverage': self.data['ebit'] / self.data['interest_expense'],
            'debt_service_coverage': self.data['operating_cash_flow'] / 
                                    (self.data['principal_payment'] + self.data['interest_expense']),
        }
        return solvency
    
    # EFFICIENCY RATIOS
    def calculate_efficiency_ratios(self) -> Dict[str, float]:
        """Calculate asset and inventory efficiency"""
        efficiency = {
            'asset_turnover': self.data['revenue'] / self.data['total_assets'],
            'receivable_turnover': self.data['revenue'] / self.data['accounts_receivable'],
            'inventory_turnover': self.data['cost_of_goods_sold'] / self.data['inventory'],
            'days_sales_outstanding': 365 / (self.data['revenue'] / self.data['accounts_receivable']),
            'days_inventory': 365 / (self.data['cost_of_goods_sold'] / self.data['inventory']),
        }
        return efficiency
    
    # GROWTH METRICS
    def calculate_growth_metrics(self, periods: int = 3) -> Dict[str, float]:
        """Calculate year-over-year growth rates"""
        growth = {
            'revenue_growth': self._calculate_cagr('revenue', periods),
            'profit_growth': self._calculate_cagr('net_profit', periods),
            'asset_growth': self._calculate_cagr('total_assets', periods),
            'equity_growth': self._calculate_cagr('equity', periods),
        }
        return growth
    
    def _calculate_cagr(self, metric: str, periods: int) -> float:
        """Calculate Compound Annual Growth Rate"""
        start_value = self.data[metric].iloc[-periods]
        end_value = self.data[metric].iloc[-1]
        cagr = ((end_value / start_value) ** (1 / periods) - 1) * 100
        return cagr
    
    # COMPREHENSIVE ANALYSIS
    def calculate_all_ratios(self) -> Dict:
        """Calculate all financial ratios"""
        self.ratios = {
            'profitability': self.calculate_profit_margins(),
            'returns': self.calculate_return_ratios(),
            'liquidity': self.calculate_liquidity_ratios(),
            'solvency': self.calculate_solvency_ratios(),
            'efficiency': self.calculate_efficiency_ratios(),
            'growth': self.calculate_growth_metrics(),
        }
        return self.ratios
    
    def get_financial_health_score(self) -> float:
        """
        Calculate comprehensive financial health score (0-100)
        Based on weighted ratios across all categories
        """
        if not self.ratios:
            self.calculate_all_ratios()
        
        weights = {
            'profitability': 0.25,
            'liquidity': 0.20,
            'solvency': 0.20,
            'efficiency': 0.20,
            'growth': 0.15,
        }
        
        scores = {
            'profitability': self._score_profitability(),
            'liquidity': self._score_liquidity(),
            'solvency': self._score_solvency(),
            'efficiency': self._score_efficiency(),
            'growth': self._score_growth(),
        }
        
        health_score = sum(scores[key] * weights[key] for key in weights)
        self.health_score = health_score
        return health_score
    
    def _score_profitability(self) -> float:
        """Score profitability metrics (0-100)"""
        npm = self.ratios['profitability'].get('net_profit_margin', 0)
        roe = self.ratios['returns'].get('roe', 0)
        return min(100, (npm + roe / 2))
    
    def _score_liquidity(self) -> float:
        """Score liquidity metrics (0-100)"""
        current_ratio = self.ratios['liquidity'].get('current_ratio', 0)
        quick_ratio = self.ratios['liquidity'].get('quick_ratio', 0)
        ideal_current = 1.5
        ideal_quick = 1.0
        score = (min(current_ratio / ideal_current, 1) * 50 + 
                min(quick_ratio / ideal_quick, 1) * 50)
        return min(100, score)
    
    def _score_solvency(self) -> float:
        """Score solvency metrics (0-100)"""
        dte = self.ratios['solvency'].get('debt_to_equity', 0)
        interest_coverage = self.ratios['solvency'].get('interest_coverage', 1)
        ideal_dte = 1.0
        dte_score = max(0, (1 - (dte / ideal_dte)) * 100) if ideal_dte > 0 else 50
        ic_score = min(interest_coverage * 10, 100)
        return (dte_score + ic_score) / 2
    
    def _score_efficiency(self) -> float:
        """Score efficiency metrics (0-100)"""
        asset_turnover = self.ratios['efficiency'].get('asset_turnover', 0)
        receivable_turnover = self.ratios['efficiency'].get('receivable_turnover', 0)
        return min(100, (asset_turnover * 20 + receivable_turnover * 3))
    
    def _score_growth(self) -> float:
        """Score growth metrics (0-100)"""
        revenue_growth = self.ratios['growth'].get('revenue_growth', 0)
        profit_growth = self.ratios['growth'].get('profit_growth', 0)
        return min(100, (revenue_growth + profit_growth) / 2 + 50)
    
    def get_assessment_report(self) -> Dict:
        """Generate comprehensive financial assessment report"""
        health_score = self.get_financial_health_score()
        
        report = {
            'overall_health_score': health_score,
            'health_status': self._get_health_status(health_score),
            'ratios': self.ratios,
            'strengths': self._identify_strengths(),
            'weaknesses': self._identify_weaknesses(),
            'recommendations': self._generate_recommendations(health_score),
        }
        return report
    
    def _get_health_status(self, score: float) -> str:
        """Determine health status based on score"""
        if score >= 80:
            return 'Excellent Financial Health'
        elif score >= 60:
            return 'Good Financial Health'
        elif score >= 40:
            return 'Fair Financial Health'
        else:
            return 'Poor Financial Health'
    
    def _identify_strengths(self) -> List[str]:
        """Identify financial strengths"""
        strengths = []
        if self.ratios['profitability'].get('net_profit_margin', 0) > 15:
            strengths.append('Strong profitability margins')
        if self.ratios['liquidity'].get('current_ratio', 0) > 1.5:
            strengths.append('Excellent liquidity position')
        if self.ratios['solvency'].get('interest_coverage', 0) > 5:
            strengths.append('Strong ability to service debt')
        if self.ratios['growth'].get('revenue_growth', 0) > 10:
            strengths.append('Healthy revenue growth')
        return strengths
    
    def _identify_weaknesses(self) -> List[str]:
        """Identify financial weaknesses"""
        weaknesses = []
        if self.ratios['profitability'].get('net_profit_margin', 0) < 5:
            weaknesses.append('Low profit margins')
        if self.ratios['liquidity'].get('current_ratio', 0) < 1.0:
            weaknesses.append('Liquidity concerns')
        if self.ratios['solvency'].get('debt_to_equity', 0) > 2:
            weaknesses.append('High leverage')
        if self.ratios['efficiency'].get('asset_turnover', 0) < 0.5:
            weaknesses.append('Poor asset utilization')
        return weaknesses
    
    def _generate_recommendations(self, health_score: float) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        if health_score < 50:
            recommendations.append('Urgent: Improve operational efficiency and reduce costs')
            recommendations.append('Review capital structure and consider debt restructuring')
        
        if self.ratios['liquidity'].get('current_ratio', 0) < 1.5:
            recommendations.append('Increase working capital management')
        
        if self.ratios['solvency'].get('debt_to_equity', 0) > 1.5:
            recommendations.append('Develop debt reduction strategy')
        
        if self.ratios['growth'].get('revenue_growth', 0) < 5:
            recommendations.append('Focus on revenue growth initiatives')
        
        return recommendations
    
    def plot_financial_trends(self, save_path: str = None):
        """Visualize financial trends"""
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # Plot 1: Profitability Trends
        axes[0, 0].plot(self.data.index, self.data['net_profit_margin'], marker='o')
        axes[0, 0].set_title('Net Profit Margin Trend')
        axes[0, 0].set_ylabel('Margin (%)')
        
        # Plot 2: Liquidity Trends
        axes[0, 1].plot(self.data.index, self.data['current_ratio'], marker='o', color='green')
        axes[0, 1].axhline(y=1.5, color='r', linestyle='--', label='Ideal Ratio')
        axes[0, 1].set_title('Current Ratio Trend')
        axes[0, 1].set_ylabel('Ratio')
        axes[0, 1].legend()
        
        # Plot 3: Debt Trend
        axes[1, 0].plot(self.data.index, self.data['debt_to_equity'], marker='o', color='red')
        axes[1, 0].set_title('Debt-to-Equity Ratio Trend')
        axes[1, 0].set_ylabel('Ratio')
        
        # Plot 4: Revenue Growth
        axes[1, 1].bar(self.data.index, self.data['revenue'], color='steelblue')
        axes[1, 1].set_title('Revenue Trend')
        axes[1, 1].set_ylabel('Revenue (₹)')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
    
    def export_report(self, filename: str = 'financial_assessment.txt'):
        """Export detailed financial assessment report"""
        report = self.get_assessment_report()
        
        with open(filename, 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("FINANCIAL HEALTH ASSESSMENT - DR REDDYS LABORATORIES\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"Overall Health Score: {report['overall_health_score']:.2f}/100\n")
            f.write(f"Status: {report['health_status']}\n\n")
            
            f.write("FINANCIAL RATIOS\n")
            f.write("-" * 80 + "\n")
            for category, ratios in report['ratios'].items():
                f.write(f"\n{category.upper()}:\n")
                for ratio, value in ratios.items():
                    f.write(f"  {ratio}: {value:.2f}\n")
            
            f.write("\n\nSTRENGTHS\n")
            f.write("-" * 80 + "\n")
            for strength in report['strengths']:
                f.write(f"  • {strength}\n")
            
            f.write("\n\nWEAKNESSES\n")
            f.write("-" * 80 + "\n")
            for weakness in report['weaknesses']:
                f.write(f"  • {weakness}\n")
            
            f.write("\n\nRECOMMENDATIONS\n")
            f.write("-" * 80 + "\n")
            for rec in report['recommendations']:
                f.write(f"  • {rec}\n")