import pandas as pd
import numpy as np
from typing import Union, Dict, List

class FinancialDataLoader:
    """Load and prepare financial data for DR Reddys analysis"""
    
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.data = None
    
    def load_data(self) -> pd.DataFrame:
        """Load financial data from CSV or Excel"""
        if self.filepath.endswith('.csv'):
            self.data = pd.read_csv(self.filepath)
        elif self.filepath.endswith('.xlsx'):
            self.data = pd.read_excel(self.filepath)
        return self.data
    
    def validate_data(self) -> bool:
        """Validate required financial fields"""
        required_fields = [
            'revenue', 'gross_profit', 'operating_profit', 'net_profit',
            'total_assets', 'current_assets', 'current_liabilities',
            'equity', 'total_debt'
        ]
        return all(field in self.data.columns for field in required_fields)
    
    def clean_data(self) -> pd.DataFrame:
        """Clean and prepare data"""
        self.data = self.data.fillna(method='ffill')
        self.data = self.data.drop_duplicates()
        return self.data