# Financial Health Assessment - DR Reddys Laboratories

A comprehensive financial analysis framework to assess the financial health of DR Reddys Laboratories Limited, a leading Indian pharmaceutical company.

## 📊 Overview

This project provides detailed financial analysis including:
- Profitability analysis (margins, ROE, ROA)
- Liquidity assessment (current ratio, quick ratio)
- Solvency analysis (debt ratios, interest coverage)
- Efficiency metrics (asset turnover, receivable turnover)
- Growth trend analysis
- Comprehensive health scoring

## 🚀 Quick Start

```python
import pandas as pd
from financial_analysis import FinancialHealthAnalyzer
from data_loader import FinancialDataLoader

# Load data
loader = FinancialDataLoader('dr_reddys_financials.csv')
data = loader.load_data()

# Analyze
analyzer = FinancialHealthAnalyzer(data)
report = analyzer.get_assessment_report()

# View results
print(f"Health Score: {report['overall_health_score']:.2f}")
print(f"Status: {report['health_status']}")